from rest_framework import serializers
from .models import Review


class ReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Review
        fields = ('id', 'title', 'content', 'updated_at')
    
    # def create(self, validated_data):
    #     content = validated_data.pop('content')
    #     user = User.objects.create(**validated_data)
    #     Profile.objects.create(user=user, **profile_data)
    #     return user
    def page(self, validated_data):
        url = validated_data.pop('content')
        return url
   