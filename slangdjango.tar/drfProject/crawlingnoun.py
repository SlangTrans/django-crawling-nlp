from soynlp.normalizer import *

from ckonlpy.tag import Twitter
from soynlp.noun import LRNounExtractor
from soynlp.word import WordExtractor
from soynlp.tokenizer import LTokenizer
from urllib.request import urlopen
from bs4 import BeautifulSoup
from pykospacing import Spacing
import re

import json, os, requests, django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', "drfProject.settings")
django.setup()
from mainApp import models
class NounCrawling:
    def __init__(self, param):
        spacing = Spacing()
        html = urlopen(param)  
        bsObject = BeautifulSoup(html, "html.parser") 
# print(bsObject) # 웹 문서 전체가 출력
# print(bsObject.get_text())
        onlytext = bsObject.get_text()
        print(type(onlytext))
# onlytext=onlytext.replace("\n","")
        onlytext = re.split(r'[ ,:,\s,\n,.]', onlytext)
# onlytext = re.split(r'\`\-\=\~\!\@\#\$\%\^\&\*\(\)\_\+\[\]\{\}\;\'\\\:\"\|\<\,\.\/\>\<\>\?\\n\\s', onlytext)
        print(type(onlytext))
# onlytext = onlytext.split(' ')
# onlytext = re.split("' '|\n|''", onlytext)
        onlytext = list(map(lambda x: x.strip(), onlytext))
        onlytext = list(filter(lambda x: x != '', onlytext))
# print(onlytext)
        StrA = " ".join(onlytext)
        twitter = Twitter()
        words=twitter.morphs(repeat_normalize(spacing(StrA)))
# noun = []
        print(words)
# print(type(words))
# for nn in words:
#     if nn[1] == 'Noun':
#         noun.append(nn[0])
# print(noun)
# twitter.add_dictionary('어쩔티비','Noun')
# words=twitter.morphs('ㅋㅋㅋㅋㅋㅋㅋㅋ어쩔티비 그냥 밥이나 먹어 하하하하')
# noun = []
# print(words)